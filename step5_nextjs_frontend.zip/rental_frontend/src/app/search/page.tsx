"use client"
import { useState } from "react"
import { useQuery } from "@tanstack/react-query"
import { propertiesApi } from "@/lib/api"
import { Property } from "@/types"
import Link from "next/link"
import { Search, SlidersHorizontal, Star, Users, Bed, Home } from "lucide-react"

function PropertyCard({ property }: { property: Property }) {
  return (
    <Link href={`/properties/${property.id}`} className="group">
      <div className="card overflow-hidden hover:shadow-card-hover transition-shadow duration-200">
        <div className="aspect-[4/3] bg-gray-100 relative overflow-hidden">
          {property.cover_photo ? (
            <img
              src={property.cover_photo}
              alt={property.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <Home className="w-10 h-10 text-gray-300" />
            </div>
          )}
          <div className="absolute top-3 right-3 bg-white/90 backdrop-blur rounded-lg px-2 py-1 text-xs font-medium capitalize text-gray-600">
            {property.property_type}
          </div>
        </div>
        <div className="p-4">
          <div className="flex items-start justify-between gap-2 mb-1">
            <h3 className="font-semibold text-gray-900 text-sm leading-snug line-clamp-2 flex-1">
              {property.title}
            </h3>
            {parseFloat(property.avg_rating) > 0 && (
              <div className="flex items-center gap-1 text-xs font-medium text-gray-700 flex-shrink-0">
                <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                {parseFloat(property.avg_rating).toFixed(1)}
              </div>
            )}
          </div>
          <p className="text-xs text-gray-500 mb-3">{property.city}, {property.country}</p>
          <div className="flex items-center gap-3 text-xs text-gray-400 mb-3">
            <span className="flex items-center gap-1">
              <Users className="w-3.5 h-3.5" /> {property.max_guests}
            </span>
            <span className="flex items-center gap-1">
              <Bed className="w-3.5 h-3.5" /> {property.beds} bed{property.beds !== 1 ? "s" : ""}
            </span>
          </div>
          <div className="flex items-baseline gap-1">
            <span className="font-bold text-gray-900">${property.price_per_night}</span>
            <span className="text-xs text-gray-400">/ night</span>
          </div>
        </div>
      </div>
    </Link>
  )
}

export default function SearchPage() {
  const [filters, setFilters] = useState({
    search:    "",
    city:      "",
    min_price: "",
    max_price: "",
    min_guests:"",
    property_type: "",
  })
  const [applied, setApplied] = useState<typeof filters>(filters)

  const { data, isLoading } = useQuery({
    queryKey: ["properties", applied],
    queryFn:  () => propertiesApi.list({
      search:         applied.search || undefined,
      city:           applied.city || undefined,
      min_price:      applied.min_price || undefined,
      max_price:      applied.max_price || undefined,
      min_guests:     applied.min_guests || undefined,
      property_type:  applied.property_type || undefined,
    }).then((r) => r.data),
  })

  const properties: Property[] = data?.results || data || []

  const applyFilters = () => setApplied({ ...filters })

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">

      {/* Search bar */}
      <div className="flex gap-3 mb-6">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            value={filters.search}
            onChange={(e) => setFilters((f) => ({ ...f, search: e.target.value }))}
            onKeyDown={(e) => e.key === "Enter" && applyFilters()}
            className="input pl-9"
            placeholder="Search by city, title, or description…"
          />
        </div>
        <button onClick={applyFilters} className="btn-primary flex items-center gap-2">
          <Search className="w-4 h-4" />
          Search
        </button>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* Filters sidebar */}
        <aside className="w-full lg:w-64 flex-shrink-0">
          <div className="card p-5 sticky top-20">
            <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
              <SlidersHorizontal className="w-4 h-4" /> Filters
            </h3>

            <div className="space-y-4">
              <div>
                <label className="label">City</label>
                <input
                  value={filters.city}
                  onChange={(e) => setFilters((f) => ({ ...f, city: e.target.value }))}
                  className="input"
                  placeholder="e.g. Paris"
                />
              </div>

              <div>
                <label className="label">Property type</label>
                <select
                  value={filters.property_type}
                  onChange={(e) => setFilters((f) => ({ ...f, property_type: e.target.value }))}
                  className="input"
                >
                  <option value="">Any</option>
                  <option value="apartment">Apartment</option>
                  <option value="house">House</option>
                  <option value="villa">Villa</option>
                  <option value="studio">Studio</option>
                  <option value="cabin">Cabin</option>
                </select>
              </div>

              <div>
                <label className="label">Price range (per night)</label>
                <div className="flex gap-2">
                  <input
                    value={filters.min_price}
                    onChange={(e) => setFilters((f) => ({ ...f, min_price: e.target.value }))}
                    className="input"
                    placeholder="Min $"
                    type="number"
                  />
                  <input
                    value={filters.max_price}
                    onChange={(e) => setFilters((f) => ({ ...f, max_price: e.target.value }))}
                    className="input"
                    placeholder="Max $"
                    type="number"
                  />
                </div>
              </div>

              <div>
                <label className="label">Min. guests</label>
                <input
                  value={filters.min_guests}
                  onChange={(e) => setFilters((f) => ({ ...f, min_guests: e.target.value }))}
                  className="input"
                  type="number"
                  placeholder="e.g. 2"
                  min={1}
                />
              </div>

              <button onClick={applyFilters} className="btn-primary w-full">
                Apply filters
              </button>
              <button
                onClick={() => {
                  const empty = { search: "", city: "", min_price: "", max_price: "", min_guests: "", property_type: "" }
                  setFilters(empty)
                  setApplied(empty)
                }}
                className="btn-ghost w-full text-sm text-gray-500"
              >
                Clear all
              </button>
            </div>
          </div>
        </aside>

        {/* Results */}
        <div className="flex-1">
          <div className="flex items-center justify-between mb-4">
            <p className="text-sm text-gray-500">
              {isLoading ? "Searching…" : `${properties.length} place${properties.length !== 1 ? "s" : ""} found`}
            </p>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="card overflow-hidden animate-pulse">
                  <div className="aspect-[4/3] bg-gray-200" />
                  <div className="p-4 space-y-2">
                    <div className="h-4 bg-gray-200 rounded w-3/4" />
                    <div className="h-3 bg-gray-200 rounded w-1/2" />
                    <div className="h-4 bg-gray-200 rounded w-1/4 mt-3" />
                  </div>
                </div>
              ))}
            </div>
          ) : properties.length === 0 ? (
            <div className="card p-16 text-center text-gray-400">
              <Home className="w-10 h-10 mx-auto mb-3 opacity-40" />
              <p className="font-medium text-gray-600">No properties found</p>
              <p className="text-sm mt-1">Try adjusting your search or filters</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5">
              {properties.map((p: Property) => (
                <PropertyCard key={p.id} property={p} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
