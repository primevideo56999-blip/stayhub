"use client"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { useAuthStore } from "@/store/auth"
import { Home, Menu, X, User, LogOut, LayoutDashboard, PlusSquare } from "lucide-react"
import { useState } from "react"
import toast from "react-hot-toast"

export function Navbar() {
  const { user, logout, isAuthenticated, isHost } = useAuthStore()
  const [open, setOpen] = useState(false)
  const pathname = usePathname()
  const router   = useRouter()

  const handleLogout = async () => {
    await logout()
    toast.success("Logged out")
    router.push("/")
  }

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur border-b border-gray-100 shadow-sm">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-16">

        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 font-display font-bold text-xl text-brand-700">
          <Home className="w-5 h-5 text-brand-500" />
          StayHub
        </Link>

        {/* Desktop nav */}
        <div className="hidden md:flex items-center gap-1">
          <Link href="/search" className={`btn-ghost text-sm ${pathname === "/search" ? "text-brand-600" : ""}`}>
            Explore
          </Link>

          {isAuthenticated() ? (
            <>
              {isHost() && (
                <Link href="/host/dashboard" className="btn-ghost text-sm">
                  <LayoutDashboard className="w-4 h-4 mr-1.5 inline" />
                  Dashboard
                </Link>
              )}
              <Link href="/trips" className="btn-ghost text-sm">My Trips</Link>
              <div className="w-px h-5 bg-gray-200 mx-1" />
              <Link href="/profile" className="flex items-center gap-2 btn-ghost text-sm">
                {user?.avatar ? (
                  <img src={user.avatar} alt="" className="w-7 h-7 rounded-full object-cover" />
                ) : (
                  <div className="w-7 h-7 rounded-full bg-brand-100 flex items-center justify-center">
                    <User className="w-4 h-4 text-brand-600" />
                  </div>
                )}
                <span>{user?.first_name}</span>
              </Link>
              <button onClick={handleLogout} className="btn-ghost text-sm text-gray-500">
                <LogOut className="w-4 h-4" />
              </button>
            </>
          ) : (
            <>
              <Link href="/login"    className="btn-ghost text-sm">Log in</Link>
              <Link href="/register" className="btn-primary text-sm">Sign up</Link>
            </>
          )}
        </div>

        {/* Mobile menu button */}
        <button onClick={() => setOpen(!open)} className="md:hidden btn-ghost p-2">
          {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </nav>

      {/* Mobile drawer */}
      {open && (
        <div className="md:hidden bg-white border-t border-gray-100 px-4 py-4 space-y-1">
          <Link href="/search"  className="block btn-ghost w-full text-left" onClick={() => setOpen(false)}>Explore</Link>
          {isAuthenticated() ? (
            <>
              {isHost() && (
                <Link href="/host/dashboard" className="block btn-ghost w-full text-left" onClick={() => setOpen(false)}>Dashboard</Link>
              )}
              <Link href="/trips"   className="block btn-ghost w-full text-left" onClick={() => setOpen(false)}>My Trips</Link>
              <Link href="/profile" className="block btn-ghost w-full text-left" onClick={() => setOpen(false)}>Profile</Link>
              <button onClick={handleLogout} className="block btn-ghost w-full text-left text-red-500">Log out</button>
            </>
          ) : (
            <>
              <Link href="/login"    className="block btn-ghost w-full text-left" onClick={() => setOpen(false)}>Log in</Link>
              <Link href="/register" className="block btn-primary w-full text-center" onClick={() => setOpen(false)}>Sign up</Link>
            </>
          )}
        </div>
      )}
    </header>
  )
}
